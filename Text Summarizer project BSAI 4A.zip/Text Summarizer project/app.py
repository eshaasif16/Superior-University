from flask import Flask, render_template, request, send_file, redirect, url_for, session, jsonify
import os
import io
import re
import numpy as np
import networkx as nx 
import PyPDF2
import time
import threading
import logging #helps in debugging and monitoring app activity

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = 'summarizer_secret_key'  
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload

# create uploads folder if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


def simple_sentence_tokenize(text):
    # spiliting text into sentences using punctuation marks.
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if s.strip()]

def simple_word_tokenize(text):
    #removes punctuation and converts text into lower letters
    return re.findall(r'\b\w+\b', text.lower())

# common stopwords list
STOPWORDS = set(['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 
                'you', 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 
                'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 
                'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 
                'which', 'who', 'whom', 'this', 'that', 'these', 'those', 'am', 
                'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 
                'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 
                'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 
                'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 
                'through', 'during', 'before', 'after', 'above', 'below', 'to', 
                'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 
                'again', 'further', 'then', 'once', 'here', 'there', 'when', 
                'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 
                'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own', 
                'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 
                'just', 'don', 'should', 'now'])

#extracting text from PDF using the library pypdf2
def extract_text_from_pdf(pdf_file):
    text = ""
    try:
        logger.info(f"Starting PDF extraction")
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            page_text = page.extract_text() or ""
            text += page_text + "\n"
            logger.info(f"Extracted page {page_num+1}/{len(pdf_reader.pages)}: {len(page_text)} chars")
        logger.info(f"PDF extraction complete:{len(text)} total chars")
        return text
    except Exception as e:
        logger.error(f"error extracting text from PDF:{e}") #if error occurs returns the same text or empty string to the user
        import traceback
        logger.error(traceback.format_exc())
        return ""
    
    
#compares two sentences and returns a similarity score using cosine similarity.
def sentence_similarity(sent1, sent2):
    # tokenization in words and sentences
    sent1_words = simple_word_tokenize(sent1)
    sent2_words = simple_word_tokenize(sent2)
    
    # stopwords removal
    sent1_words = [word for word in sent1_words if word not in STOPWORDS]
    sent2_words = [word for word in sent2_words if word not in STOPWORDS]
    #now we will create a list of all unique words found in both sentences.
    all_words = list(set(sent1_words + sent2_words))
    
    if not all_words:
        return 0.0
    
    vector1 = [0] * len(all_words)
    vector2 = [0] * len(all_words)
    
    # creating vector  for 1st and 2nd sentence
    for w in sent1_words:
        vector1[all_words.index(w)] += 1
    for w in sent2_words:
        vector2[all_words.index(w)] += 1
    
    #cosine similarity calculation
    # if both vectors are zero, it will return 0.0 to avoid division by zero
    if sum(vector1) == 0 or sum(vector2) == 0:
        return 0.0
    
    # Calculate dot product
    dot_product = sum(v1 * v2 for v1, v2 in zip(vector1, vector2))
    magnitude1 = sum(v ** 2 for v in vector1) ** 0.5 #magnitude is the lenght of each vector here 
    magnitude2 = sum(v ** 2 for v in vector2) ** 0.5
    
    if magnitude1 * magnitude2 == 0:
        return 0.0
    
    return dot_product / (magnitude1 * magnitude2)

def build_similarity_matrix(sentences):
    # Create an empty similarity matrix
    similarity_matrix = np.zeros((len(sentences), len(sentences)))
    
    for idx1 in range(len(sentences)):
        for idx2 in range(len(sentences)):
            if idx1 == idx2:  # Same sentences
                similarity_matrix[idx1][idx2] = 1.0
            else:
                similarity_matrix[idx1][idx2] = sentence_similarity(sentences[idx1], sentences[idx2])
    
    return similarity_matrix

def generate_summary(text, num_sentences=5):
    #  read text and tokenize
    sentences = simple_sentence_tokenize(text)
    logger.info(f"Tokenized text into {len(sentences)} sentences")
    if len(sentences) <= num_sentences:
        logger.info(f"Text has fewer sentences ({len(sentences)}) than requested summary length ({num_sentences}). Returning original text.")
        return " ".join(sentences)
    
    # generate similarity matrix
    sentence_similarity_matrix = build_similarity_matrix(sentences)
    logger.info(f"Built similarity matrix of shape {sentence_similarity_matrix.shape}")
    
    # rank sentences using PageRank algorithm
    sentence_similarity_graph = nx.from_numpy_array(sentence_similarity_matrix)
    scores = nx.pagerank(sentence_similarity_graph)
    logger.info(f"Calculated PageRank scores for {len(scores)} sentences")
    
    # sort the sentences by score and select top sentences
    ranked_sentences = sorted(((scores[i], s) for i, s in enumerate(sentences)), reverse=True)
    
    # Get the top N sentences as the summary
    summarize_text = []
    for i in range(min(num_sentences, len(ranked_sentences))):
        summarize_text.append(ranked_sentences[i][1])
    
    # reorder the selected sentences based on their original order
    ordered_summarize_text = [s for _, s in sorted([(sentences.index(sentence), sentence) for sentence in summarize_text])]
    
    # return the summarized text
    summary = " ".join(ordered_summarize_text)
    logger.info(f"Generated summary of {len(summary)} chars")
    return summary

def process_text_async(text, num_sentences, session_id):
    try:
        logger.info(f"Starting async processing for session {session_id}")
       
        summary_text = generate_summary(text, num_sentences)
        
        # stats calcu
        word_count = len(text.split())
        summary_word_count = len(summary_text.split())
        char_count = len(text)
        summary_char_count = len(summary_text)
        compression_ratio = round((1 - (summary_word_count / word_count)) * 100, 1)
        
        logger.info(f"Summary stats: {word_count} words → {summary_word_count} words ({compression_ratio}% compression)")
        
        # Store results in app.config for retrieval
        app.config[f'summary_{session_id}'] = {
            'summary': summary_text,
            'stats': {
                'original_word_count': word_count,
                'summary_word_count': summary_word_count,
                'original_char_count': char_count,
                'summary_char_count': summary_char_count,
                'compression_ratio': compression_ratio
            },
            'status': 'completed'
        }
    except Exception as e:
        import traceback
        logger.error(f"Error in async processing: {e}")
        logger.error(traceback.format_exc())
        app.config[f'summary_{session_id}'] = {
            'error': str(e),
            'status': 'error'
        }
@app.route('/')
def index():
    return render_template('index.html', 
                          summary=session.get('summary'),
                          original_text=session.get('original_text'),
                          stats=session.get('stats'),
                          error=session.get('error'))

@app.route('/summarize', methods=['POST'])
def summarize_text():
    logger.info("Form submitted to /summarize")
    
    # Clear previous session data
    session.pop('summary', None)
    session.pop('original_text', None)
    session.pop('stats', None)
    session.pop('error', None)
   
    text = ""
    if request.form.get('text', '').strip():
        text = request.form.get('text', '')
        logger.info(f"Received text input: {len(text)} chars")
    elif 'file' in request.files:
        file = request.files['file']
        if file.filename != '':
            try:
                logger.info(f"Received file: {file.filename}")
              
                file_ext = os.path.splitext(file.filename)[1].lower()
                
                if file_ext == '.pdf':
                    text = extract_text_from_pdf(file)
                    if not text:
                        session['error'] ='Could not extract text from PDF. The file might be encrypted or damaged.'
                        logger.error("PDF extraction failed - no text extracted")
                        return redirect(url_for('index'))
                elif file_ext == '.txt':
                    # will read file text
                    text = file.read().decode('utf-8')
                    logger.info(f"Read text file: {len(text)} chars")
                else:
                    session['error'] = 'Unsupported file format. Please upload a .txt or .pdf file.'
                    logger.error(f"Unsupported file format: {file_ext}")
                    return redirect(url_for('index'))
                    
            except UnicodeDecodeError:
                session['error'] ='File encoding not supported. Please use UTF-8.'
                logger.error("UnicodeDecodeError when reading file")
                return redirect(url_for('index'))
            except Exception as e:
                session['error'] = f'Error processing file: {str(e)}'
                logger.error(f"Error processing file: {e}")
                return redirect(url_for('index'))
    if not text.strip():
        session['error'] ='Please enter text or upload a file'
        logger.error("No text provided")
        return redirect(url_for('index'))
    
    #this will checkif text is long enough to summarize
    if len(text.split()) < 20:
        session['error'] = 'Text is too short to summarize. Please provide a longer text (at least 20 words).'
        logger.error(f"Text too short: {len(text.split())} words")
        return redirect(url_for('index'))
    summary_length = int(request.form.get('summary_length', 5))
    logger.info(f"Summary length parameter: {summary_length}")
    
    session['original_text'] = text
    
    #generate a unique session id for this summarization task
    session_id = str(time.time())
    session['summary_id'] = session_id
    
    app.config[f'summary_{session_id}'] = {'status': 'processing'}
    
    # processing in a background thread
    thread = threading.Thread(target=process_text_async, args=(text, summary_length, session_id))
    thread.daemon = True
    thread.start()
    
    logger.info(f"Started async processing thread for session {session_id}")
    return redirect(url_for('check_status'))

@app.route('/check_status')
def check_status():
    session_id = session.get('summary_id')
    if not session_id:
        logger.error("No session_id found in session")
        return redirect(url_for('index'))
    
    logger.info(f"Rendering loading page for session {session_id}")
    return render_template('loading.html')

@app.route('/api/status')
def api_status():
    session_id = session.get('summary_id')
    if not session_id or f'summary_{session_id}' not in app.config:
        logger.error(f"No task found for session: {session_id}")
        return jsonify({'status':'error','message':'No task found'})
    
    result = app.config[f'summary_{session_id}']
    logger.info(f"Status check forsession {session_id}:{result['status']}")
    
    if result['status'] == 'completed':
     
        session['summary'] = result['summary']
        session['stats'] = result['stats']
      
        app.config.pop(f'summary_{session_id}', None)
        return jsonify({'status': 'completed', 'redirect': url_for('result')})
    elif result['status'] == 'error':
        session['error'] = result['error']
       
        app.config.pop(f'summary_{session_id}', None)
        return jsonify({'status': 'error', 'redirect': url_for('index')})
    else:
        return jsonify({'status': 'processing'})
@app.route('/result')
def result():
    if not session.get('summary'):
        logger.error("No summary found in session")
        return redirect(url_for('index'))
    logger.info("Rendering result page")
    return render_template('result.html',
                          summary=session.get('summary'),
                          original_text=session.get('original_text'),
                          stats=session.get('stats'))

@app.route('/download_summary', methods=['POST'])
def download_summary():
    summary = session.get('summary', '')
    if not summary:
        session['error'] ='No summary available to download'
        logger.error("No summary available to download")
        return redirect(url_for('index'))
    
    buffer = io.BytesIO()
    buffer.write(summary.encode('utf-8'))
    buffer.seek(0)
    
    logger.info("Sending summary file for download")
    return send_file(
        buffer,
        as_attachment=True,
        download_name='summary.txt',
        mimetype='text/plain'
    )
@app.route('/clear', methods=['POST'])
def clear():
    logger.info("Clearing session data")
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
    
  #The Evolving Landscape of Artificial Intelligence
# Artificial Intelligence (AI) has transitioned from a futuristic concept into a fundamental technology that is reshaping every aspect of modern life. 
# Initially confined to academic research and niche applications, 
# AI now permeates industries ranging from healthcare and finance to education, entertainment, and agriculture. 
# The core objective of AI — to create systems capable of mimicking human intelligence — is being pursued through numerous subfields, including machine learning, natural language processing, computer vision, and robotics.
# At the heart of recent AI advancements lies machine learning (ML), particularly deep learning. 
# These systems, trained on vast datasets, can identify complex patterns and make autonomous decisions with minimal human intervention. 
# For example, convolutional neural networks (CNNs) have revolutionized image recognition, allowing machines to accurately identify objects, facial expressions, and even diagnose diseases from medical images.
# Natural Language Processing (NLP) has given rise to sophisticated language models that understand and generate human language with remarkable fluency. Tools like ChatGPT and other transformer-based models can summarize articles, write essays, answer questions, translate languages, and even create poetry or code — blurring the line between human and machine communication. 
# This has led to their widespread adoption in customer service, virtual assistants, and content creation.
# AI in healthcare is particularly transformative. AI-powered diagnostic tools assist doctors by flagging abnormalities in radiology scans, predicting disease outbreaks, and personalizing treatment plans based on a patient's genetic profile. 
# AI models are also being used to design new drugs at unprecedented speeds, significantly accelerating the drug discovery process.
# Meanwhile, autonomous vehicles and robotics illustrate how AI interacts with the physical world. 
# Self-driving cars use computer vision, sensor fusion, and deep learning to navigate complex environments.
# Industrial robots equipped with AI can adapt to changes on the factory floor, improving efficiency and safety.
# Yet, as AI's capabilities grow, so do ethical and societal concerns. Bias in algorithms, stemming from imbalanced training data, can lead to unfair treatment in critical areas like hiring, lending, and criminal justice. 
# The rise of deepfakes and misinformation also raises questions about trust and authenticity in the digital age. 
# Moreover, fears of job displacement due to automation challenge policymakers to rethink education, workforce development, and social safety nets.
# To mitigate these risks, researchers and organizations emphasize the importance of explainable AI (XAI), fairness audits, and robust regulatory frameworks.
# Initiatives promoting AI for Good focus on using AI to tackle global challenges such as climate change, food insecurity, and disaster response.
# In the near future, AI is expected to become even more embedded in daily life — from smart homes and personalized education systems to intelligent prosthetics and emotional AI. T
# he integration of quantum computing and AI may unlock computational power beyond our current imagination, allowing for even more sophisticated models and real-time learning.
# Ultimately, the story of AI is not just a technical one — it's a human story. It is about how we design, govern, and coexist with a new form of intelligence that has the potential to amplify our capabilities, expand our understanding, and redefine what it means to be intelligent.

