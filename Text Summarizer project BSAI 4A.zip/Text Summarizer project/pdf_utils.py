import PyPDF2
import logging

logger = logging.getLogger(__name__)

def extract_text_from_pdf(pdf_file):
    """Extract text from PDF using PyPDF2"""
    text = ""
    try:
        logger.info(f"Starting PDF extraction with PyPDF2")
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        for page_num in range(len(pdf_reader.pages)):
            page = pdf_reader.pages[page_num]
            page_text = page.extract_text() or ""
            text += page_text + "\n"
            logger.info(f"Extracted page {page_num+1}/{len(pdf_reader.pages)}: {len(page_text)} chars")
        logger.info(f"PDF extraction complete: {len(text)} total chars")
        
        # if PyPDF2 failed to extract meaningful text, will use pdfplumber
        if len(text.strip()) < 50:
            logger.warning("PyPDF2 extracted very little text, trying alternative method")
            try:
                import pdfplumber
                text = extract_with_pdfplumber(pdf_file)
            except ImportError:
                logger.warning("pdfplumber not installed, can't use alternative method")
                pass
        
        return text
    except Exception as e:
        logger.error(f"Error extracting text from PDF with PyPDF2: {e}")
        import traceback
        logger.error(traceback.format_exc())
        
        #if pypdf2 fails
        try:
            import pdfplumber
            logger.info("Trying alternative PDF extraction with pdfplumber")
            return extract_with_pdfplumber(pdf_file)
        except ImportError:
            logger.error("pdfplumber not installed, can't use alternative method")
            return ""
        except Exception as e:
            logger.error(f"Error with alternative PDF extraction: {e}")
            return ""

def extract_with_pdfplumber(pdf_file):
    """Extract text from PDF using pdfplumber (alternative method)"""
    import pdfplumber
    text = ""
    try:
        with pdfplumber.open(pdf_file) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text += page_text + "\n"
                logger.info(f"pdfplumber extracted page: {len(page_text)} chars")
        logger.info(f"pdfplumber extraction complete: {len(text)} total chars")
        return text
    except Exception as e:
        logger.error(f"Error with pdfplumber: {e}")
        import traceback
        logger.error(traceback.format_exc())
        return ""